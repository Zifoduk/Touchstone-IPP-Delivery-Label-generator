To install open the folder setup and open the TS Installer setup.exe
