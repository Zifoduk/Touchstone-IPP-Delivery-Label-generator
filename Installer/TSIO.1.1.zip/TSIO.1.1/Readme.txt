To install open the folder setup and open the TS Installer setup.exe.
Documentation can be founder under the documentation folder.